// ─────────────────────────────────────────────────────────────
// darsanai.AI — Plans, Pricing & Credit Packs Configuration
// This is the single source of truth for all pricing.
// Change prices here and they reflect everywhere.
// ─────────────────────────────────────────────────────────────

// ── SUBSCRIPTION PLANS ────────────────────────────────────────
const PLANS = {
  free: {
    id:             'free',
    name:           'Starter',
    price:          0,
    currency:       'usd',
    interval:       'month',
    stripePriceId:  null,             // free plan — no Stripe needed
    credits:        20,               // credits per month
    features: {
      maxDuration:    5,              // max seconds per video
      maxResolution:  '720p',
      watermark:      true,
      concurrentJobs: 1,
      apiAccess:      false,
    },
    description:    'Try darsanai for free — 20 generations/month',
    cta:            'Get Started Free',
    highlighted:    false,
  },

  creator: {
    id:             'creator',
    name:           'Creator',
    price:          29,
    currency:       'usd',
    interval:       'month',
    stripePriceId:  process.env.STRIPE_PRICE_CREATOR,
    credits:        300,              // credits per month
    features: {
      maxDuration:    15,
      maxResolution:  '4K',
      watermark:      false,
      concurrentJobs: 3,
      apiAccess:      false,
    },
    description:    'For professional creators and filmmakers',
    cta:            'Start Free Trial',
    highlighted:    true,             // "most popular" badge
    trialDays:      7,
  },

  studio: {
    id:             'studio',
    name:           'Studio',
    price:          99,
    currency:       'usd',
    interval:       'month',
    stripePriceId:  process.env.STRIPE_PRICE_STUDIO,
    credits:        Infinity,         // unlimited
    features: {
      maxDuration:    60,
      maxResolution:  '4K',
      watermark:      false,
      concurrentJobs: 10,
      apiAccess:      true,
      customModels:   true,
      teamSeats:      5,
    },
    description:    'For studios and production teams',
    cta:            'Contact Sales',
    highlighted:    false,
  },
};

// ── CREDIT PACKS (one-time purchases) ─────────────────────────
// Available to any plan when they need extra credits
const CREDIT_PACKS = {
  small: {
    id:            'small',
    credits:       100,
    price:         4.99,
    currency:      'usd',
    stripePriceId: process.env.STRIPE_PRICE_CREDITS_100,
    label:         '100 Credits',
    badge:         null,
    pricePerCredit: 0.05,
  },
  medium: {
    id:            'medium',
    credits:       500,
    price:         19.99,
    currency:      'usd',
    stripePriceId: process.env.STRIPE_PRICE_CREDITS_500,
    label:         '500 Credits',
    badge:         'Best Value',
    pricePerCredit: 0.04,
    savings:       '20% off',
  },
  large: {
    id:            'large',
    credits:       2000,
    price:         59.99,
    currency:      'usd',
    stripePriceId: process.env.STRIPE_PRICE_CREDITS_2000,
    label:         '2000 Credits',
    badge:         'Best Deal',
    pricePerCredit: 0.03,
    savings:       '40% off',
  },
};

// ── CREDIT COSTS per video ────────────────────────────────────
// How many credits per second of generated video
const CREDITS_PER_SECOND = parseInt(process.env.CREDITS_PER_SECOND) || 2;

function calculateCreditCost(durationSeconds) {
  return durationSeconds * CREDITS_PER_SECOND;
}

// ── PLAN HELPERS ──────────────────────────────────────────────
function getPlan(planId) {
  return PLANS[planId] || PLANS.free;
}

function getPlanByStripePriceId(priceId) {
  return Object.values(PLANS).find(p => p.stripePriceId === priceId);
}

function getCreditPack(packId) {
  return CREDIT_PACKS[packId];
}

function canGenerateVideo(userPlan, durationSeconds, resolution) {
  const plan = getPlan(userPlan);
  if (durationSeconds > plan.features.maxDuration) {
    return { allowed: false, reason: `Your plan allows max ${plan.features.maxDuration}s videos. Upgrade to generate longer videos.` };
  }
  const resolutionRank = { '720p': 1, '1080p': 2, '4K': 3 };
  if ((resolutionRank[resolution] || 1) > (resolutionRank[plan.features.maxResolution] || 1)) {
    return { allowed: false, reason: `Your plan does not support ${resolution}. Upgrade to unlock higher resolution.` };
  }
  return { allowed: true };
}

module.exports = {
  PLANS,
  CREDIT_PACKS,
  CREDITS_PER_SECOND,
  calculateCreditCost,
  getPlan,
  getPlanByStripePriceId,
  getCreditPack,
  canGenerateVideo,
};
