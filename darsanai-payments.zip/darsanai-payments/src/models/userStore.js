// ─────────────────────────────────────────────────────────────
// darsanai.AI — User & Credit Store
// Stores user plans, credits, and transaction history.
// In production: replace with PostgreSQL using Prisma or Knex.
// ─────────────────────────────────────────────────────────────
const { PLANS, getPlan } = require('../config/plans');

// In-memory stores (replace with DB tables in production)
const users        = new Map();   // userId → userRecord
const transactions = new Map();   // transactionId → txRecord

// ── TRANSACTION TYPES ─────────────────────────────────────────
const TX_TYPE = {
  CREDIT_GRANT:    'credit_grant',       // monthly plan credits
  CREDIT_PURCHASE: 'credit_purchase',    // one-time pack purchase
  CREDIT_DEDUCT:   'credit_deduct',      // used for generation
  REFUND:          'refund',
};

// ── GET OR CREATE USER ────────────────────────────────────────
function getOrCreateUser(userId) {
  if (!users.has(userId)) {
    const newUser = {
      id:               userId,
      plan:             'free',
      stripeCustomerId: null,
      stripeSubId:      null,
      credits:          parseInt(process.env.FREE_TIER_CREDITS) || 20,
      creditsUsed:      0,
      totalSpend:       0,             // lifetime spend in cents
      createdAt:        new Date().toISOString(),
      planActivatedAt:  new Date().toISOString(),
      nextBillingDate:  null,
    };
    users.set(userId, newUser);
    console.log(`👤 New user created: ${userId}`);
  }
  return users.get(userId);
}

// ── GET USER ──────────────────────────────────────────────────
function getUser(userId) {
  return getOrCreateUser(userId);
}

// ── UPDATE USER ───────────────────────────────────────────────
function updateUser(userId, updates) {
  const user = getOrCreateUser(userId);
  const updated = { ...user, ...updates, updatedAt: new Date().toISOString() };
  users.set(userId, updated);
  return updated;
}

// ── ACTIVATE PLAN ─────────────────────────────────────────────
function activatePlan(userId, planId, stripeSubId) {
  const plan = getPlan(planId);

  // Grant monthly credits
  const now  = new Date();
  const next = new Date(now);
  next.setMonth(next.getMonth() + 1);

  const updated = updateUser(userId, {
    plan:             planId,
    stripeSubId,
    credits:          plan.credits === Infinity ? 99999 : plan.credits,
    planActivatedAt:  now.toISOString(),
    nextBillingDate:  next.toISOString(),
  });

  // Log the transaction
  addTransaction({
    userId,
    type:    TX_TYPE.CREDIT_GRANT,
    amount:  0,
    credits: plan.credits === Infinity ? 99999 : plan.credits,
    note:    `Plan activated: ${plan.name}`,
  });

  console.log(`✅ Plan activated for ${userId}: ${planId} (${plan.credits} credits)`);
  return updated;
}

// ── CANCEL PLAN ───────────────────────────────────────────────
function cancelPlan(userId) {
  return updateUser(userId, {
    plan:         'free',
    stripeSubId:  null,
    credits:      parseInt(process.env.FREE_TIER_CREDITS) || 20,
  });
}

// ── ADD CREDITS (from pack purchase) ─────────────────────────
function addCredits(userId, amount, note = '') {
  const user = getOrCreateUser(userId);
  const updated = updateUser(userId, { credits: user.credits + amount });

  addTransaction({
    userId,
    type:    TX_TYPE.CREDIT_PURCHASE,
    amount:  0,
    credits: amount,
    note:    note || `Purchased ${amount} credits`,
  });

  console.log(`💰 +${amount} credits for ${userId} (total: ${updated.credits})`);
  return updated.credits;
}

// ── DEDUCT CREDITS (for video generation) ────────────────────
function deductCredits(userId, amount, jobId) {
  const user = getOrCreateUser(userId);

  if (user.credits < amount) {
    throw new Error(`Insufficient credits: have ${user.credits}, need ${amount}`);
  }

  const updated = updateUser(userId, {
    credits:     user.credits - amount,
    creditsUsed: user.creditsUsed + amount,
  });

  addTransaction({
    userId,
    type:    TX_TYPE.CREDIT_DEDUCT,
    amount:  0,
    credits: -amount,
    jobId,
    note:    `Video generation — ${amount} credits`,
  });

  return updated.credits;
}

// ── CHECK CREDITS ─────────────────────────────────────────────
function hasEnoughCredits(userId, amount) {
  const user = getOrCreateUser(userId);
  return user.credits >= amount;
}

// ── RECORD STRIPE CUSTOMER ID ─────────────────────────────────
function setStripeCustomerId(userId, stripeCustomerId) {
  return updateUser(userId, { stripeCustomerId });
}

// ── FIND USER BY STRIPE CUSTOMER ID ──────────────────────────
function getUserByStripeCustomerId(stripeCustomerId) {
  for (const user of users.values()) {
    if (user.stripeCustomerId === stripeCustomerId) return user;
  }
  return null;
}

// ── TRANSACTIONS ──────────────────────────────────────────────
function addTransaction(data) {
  const id = `tx_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const tx = { id, ...data, createdAt: new Date().toISOString() };
  transactions.set(id, tx);
  return tx;
}

function getUserTransactions(userId) {
  return [...transactions.values()]
    .filter(t => t.userId === userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

module.exports = {
  TX_TYPE,
  getUser,
  updateUser,
  getOrCreateUser,
  activatePlan,
  cancelPlan,
  addCredits,
  deductCredits,
  hasEnoughCredits,
  setStripeCustomerId,
  getUserByStripeCustomerId,
  addTransaction,
  getUserTransactions,
};
