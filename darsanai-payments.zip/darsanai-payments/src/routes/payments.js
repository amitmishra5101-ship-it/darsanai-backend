// ─────────────────────────────────────────────────────────────
// darsanai.AI — /api/payments Routes
//
// GET  /api/payments/plans              → list all plans
// POST /api/payments/checkout/plan      → create plan checkout
// POST /api/payments/checkout/credits   → create credit pack checkout
// POST /api/payments/portal             → open Stripe billing portal
// GET  /api/payments/session/:id        → verify a completed checkout
// ─────────────────────────────────────────────────────────────
const express = require('express');
const router  = express.Router();

const stripeService = require('../services/stripeService');
const userStore     = require('../models/userStore');
const { PLANS, CREDIT_PACKS } = require('../../config/plans');

// Simple auth middleware (replace with Clerk in production)
function requireAuth(req, res, next) {
  const userId = req.headers['x-user-id'] || req.headers['authorization']?.replace('Bearer ', '');
  if (!userId) return res.status(401).json({ error: 'Authentication required' });
  req.userId = userId;
  next();
}

// ─────────────────────────────────────────────────────────────
// GET /api/payments/plans
// Returns all available plans — used to render the pricing page
// ─────────────────────────────────────────────────────────────
router.get('/plans', (req, res) => {
  const plans = Object.values(PLANS).map(p => ({
    id:          p.id,
    name:        p.name,
    price:       p.price,
    currency:    p.currency,
    interval:    p.interval,
    credits:     p.credits === Infinity ? 'Unlimited' : p.credits,
    features:    p.features,
    description: p.description,
    cta:         p.cta,
    highlighted: p.highlighted,
    trialDays:   p.trialDays || 0,
  }));

  const packs = Object.values(CREDIT_PACKS).map(p => ({
    id:       p.id,
    credits:  p.credits,
    price:    p.price,
    currency: p.currency,
    label:    p.label,
    badge:    p.badge,
    savings:  p.savings,
  }));

  return res.json({ plans, creditPacks: packs });
});

// ─────────────────────────────────────────────────────────────
// POST /api/payments/checkout/plan
// Body: { planId, email, name }
// Returns: { checkoutUrl } — redirect user to this URL
// ─────────────────────────────────────────────────────────────
router.post('/checkout/plan', requireAuth, async (req, res) => {
  try {
    const { planId, email = 'user@example.com', name = 'darsanai User' } = req.body;

    if (!planId || !PLANS[planId]) {
      return res.status(400).json({ error: `Invalid plan: ${planId}` });
    }
    if (planId === 'free') {
      return res.status(400).json({ error: 'No checkout needed for the free plan' });
    }

    // Create or retrieve Stripe customer
    const customer = await stripeService.getOrCreateCustomer(req.userId, email, name);
    userStore.setStripeCustomerId(req.userId, customer.id);

    const baseUrl = process.env.FRONTEND_URL || 'http://localhost:5173';

    // Create Stripe checkout session
    const session = await stripeService.createSubscriptionCheckout({
      customerId:  customer.id,
      planId,
      userId:      req.userId,
      successUrl:  `${baseUrl}/dashboard?payment=success`,
      cancelUrl:   `${baseUrl}/pricing?payment=cancelled`,
    });

    return res.json({
      checkoutUrl: session.url,
      sessionId:   session.id,
    });

  } catch (err) {
    console.error('Checkout/plan error:', err.message);
    return res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/payments/checkout/credits
// Body: { packId }
// Returns: { checkoutUrl }
// ─────────────────────────────────────────────────────────────
router.post('/checkout/credits', requireAuth, async (req, res) => {
  try {
    const { packId, email = 'user@example.com', name = 'darsanai User' } = req.body;

    if (!packId || !CREDIT_PACKS[packId]) {
      return res.status(400).json({ error: `Invalid credit pack: ${packId}` });
    }

    const customer = await stripeService.getOrCreateCustomer(req.userId, email, name);
    userStore.setStripeCustomerId(req.userId, customer.id);

    const baseUrl = process.env.FRONTEND_URL || 'http://localhost:5173';

    const session = await stripeService.createCreditPackCheckout({
      customerId: customer.id,
      packId,
      userId:     req.userId,
      successUrl: `${baseUrl}/dashboard?credits=added&pack=${packId}`,
      cancelUrl:  `${baseUrl}/pricing`,
    });

    return res.json({
      checkoutUrl: session.url,
      sessionId:   session.id,
    });

  } catch (err) {
    console.error('Checkout/credits error:', err.message);
    return res.status(500).json({ error: 'Failed to create credits checkout' });
  }
});

// ─────────────────────────────────────────────────────────────
// POST /api/payments/portal
// Opens Stripe's customer portal for managing subscriptions
// Returns: { portalUrl }
// ─────────────────────────────────────────────────────────────
router.post('/portal', requireAuth, async (req, res) => {
  try {
    const user = userStore.getUser(req.userId);

    if (!user.stripeCustomerId) {
      return res.status(400).json({ error: 'No active subscription found' });
    }

    const baseUrl = process.env.FRONTEND_URL || 'http://localhost:5173';

    const session = await stripeService.createBillingPortalSession(
      user.stripeCustomerId,
      `${baseUrl}/settings`
    );

    return res.json({ portalUrl: session.url });

  } catch (err) {
    console.error('Portal error:', err.message);
    return res.status(500).json({ error: 'Failed to open billing portal' });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/payments/session/:sessionId
// Called after user returns from Stripe checkout
// Verifies the payment was successful
// ─────────────────────────────────────────────────────────────
router.get('/session/:sessionId', requireAuth, async (req, res) => {
  try {
    const session = await stripeService.getCheckoutSession(req.params.sessionId);

    if (session.payment_status !== 'paid' && session.status !== 'complete') {
      return res.json({ success: false, status: session.status });
    }

    // Return updated user info
    const user = userStore.getUser(req.userId);

    return res.json({
      success:  true,
      plan:     user.plan,
      credits:  user.credits,
      message:  'Payment successful! Your plan has been activated.',
    });

  } catch (err) {
    console.error('Session verify error:', err.message);
    return res.status(500).json({ error: 'Failed to verify payment session' });
  }
});

// ─────────────────────────────────────────────────────────────
// GET /api/payments/status
// Returns current user's subscription and credit status
// ─────────────────────────────────────────────────────────────
router.get('/status', requireAuth, (req, res) => {
  const user = userStore.getUser(req.userId);
  const plan = PLANS[user.plan] || PLANS.free;

  return res.json({
    plan: {
      id:      user.plan,
      name:    plan.name,
      credits: user.credits,
      total:   plan.credits === Infinity ? 'Unlimited' : plan.credits,
      features: plan.features,
    },
    billing: {
      nextBillingDate:  user.nextBillingDate,
      stripeCustomerId: user.stripeCustomerId ? '••••' + user.stripeCustomerId.slice(-4) : null,
    },
    transactions: userStore.getUserTransactions(req.userId).slice(0, 10),
  });
});

module.exports = router;
