// ─────────────────────────────────────────────────────────────
// darsanai.AI — /api/credits Routes
// GET  /api/credits              → get user's current credits
// POST /api/credits/check        → check if user has enough credits
// POST /api/credits/deduct       → deduct credits (called by video worker)
// GET  /api/credits/transactions → transaction history
// ─────────────────────────────────────────────────────────────
const express   = require('express');
const router    = express.Router();
const userStore = require('../models/userStore');
const { calculateCreditCost, canGenerateVideo } = require('../../config/plans');

function requireAuth(req, res, next) {
  const userId = req.headers['x-user-id'] || req.headers['authorization']?.replace('Bearer ', '');
  if (!userId) return res.status(401).json({ error: 'Authentication required' });
  req.userId = userId;
  next();
}

// ── GET current credit balance ────────────────────────────────
router.get('/', requireAuth, (req, res) => {
  const user = userStore.getUser(req.userId);
  return res.json({
    available:   user.credits,
    used:        user.creditsUsed,
    plan:        user.plan,
  });
});

// ── CHECK if user can generate a video ───────────────────────
router.post('/check', requireAuth, (req, res) => {
  const { duration = 5, resolution = '1080p' } = req.body;
  const user = userStore.getUser(req.userId);

  // Check plan limits (duration, resolution)
  const planCheck = canGenerateVideo(user.plan, parseInt(duration), resolution);
  if (!planCheck.allowed) {
    return res.status(403).json({ allowed: false, reason: planCheck.reason, upgradeRequired: true });
  }

  // Check credit balance
  const cost = calculateCreditCost(parseInt(duration));
  if (user.credits < cost) {
    return res.status(402).json({
      allowed:          false,
      reason:           `Not enough credits. You need ${cost} credits but have ${user.credits}.`,
      creditsNeeded:    cost,
      creditsAvailable: user.credits,
      upgradeRequired:  false,   // they can buy a credit pack instead
    });
  }

  return res.json({
    allowed:          true,
    creditsRequired:  cost,
    creditsAvailable: user.credits,
    creditsAfter:     user.credits - cost,
  });
});

// ── DEDUCT credits (called by the video worker after success) ──
// This route is secured by an internal API secret, not user auth
router.post('/deduct', (req, res) => {
  const secret = req.headers['x-api-secret'];
  if (secret !== process.env.API_SECRET) {
    return res.status(403).json({ error: 'Invalid API secret' });
  }

  const { userId, duration, jobId } = req.body;
  if (!userId || !duration) {
    return res.status(400).json({ error: 'userId and duration required' });
  }

  try {
    const cost      = calculateCreditCost(parseInt(duration));
    const remaining = userStore.deductCredits(userId, cost, jobId);
    return res.json({ success: true, creditsDeducted: cost, creditsRemaining: remaining });
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
});

// ── TRANSACTION HISTORY ───────────────────────────────────────
router.get('/transactions', requireAuth, (req, res) => {
  const transactions = userStore.getUserTransactions(req.userId);
  return res.json({ total: transactions.length, transactions });
});

module.exports = router;
