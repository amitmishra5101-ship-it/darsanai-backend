// ─────────────────────────────────────────────────────────────
// darsanai.AI — Payments Server
// Can run standalone (port 3002) or be merged into main backend
// ─────────────────────────────────────────────────────────────
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const helmet   = require('helmet');
const morgan   = require('morgan');

const { handleStripeWebhook } = require('./webhooks/stripeWebhook');
const paymentsRoutes = require('./routes/payments');
const creditsRoutes  = require('./routes/credits');

const app  = express();
const PORT = process.env.PORT || 3002;

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(morgan('dev'));

// ── STRIPE WEBHOOK (must use raw body, registered BEFORE express.json) ──
app.post(
  '/webhooks/stripe',
  express.raw({ type: 'application/json' }),
  handleStripeWebhook
);

// ── JSON body parsing for all other routes ────────────────────
app.use(express.json());

// ── ROUTES ────────────────────────────────────────────────────
app.use('/api/payments', paymentsRoutes);
app.use('/api/credits',  creditsRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'darsanai-payments' }));

app.listen(PORT, () => {
  console.log(`\n💳 darsanai Payments Server running on http://localhost:${PORT}`);
  console.log(`🔑 Stripe mode: ${process.env.STRIPE_SECRET_KEY?.startsWith('sk_live') ? 'LIVE 🚨' : 'TEST ✅'}\n`);
});
