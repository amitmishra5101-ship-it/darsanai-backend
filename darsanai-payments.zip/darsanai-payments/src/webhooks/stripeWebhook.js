// ─────────────────────────────────────────────────────────────
// darsanai.AI — Stripe Webhook Handler
//
// Stripe calls this endpoint to notify us about payment events.
// This is how we know when:
//   - A user paid for a subscription → give them credits
//   - A subscription renews → refresh credits
//   - A subscription cancels → downgrade to free
//   - A credit pack was purchased → add credits
//
// IMPORTANT: This must use express.raw() NOT express.json()
// because Stripe signature verification needs the raw body.
// ─────────────────────────────────────────────────────────────
const { constructWebhookEvent } = require('../services/stripeService');
const userStore  = require('../models/userStore');
const { getPlanByStripePriceId, getCreditPack } = require('../../config/plans');

async function handleStripeWebhook(req, res) {
  const signature = req.headers['stripe-signature'];

  // ── STEP 1: Verify the webhook came from Stripe ───────────
  let event;
  try {
    event = constructWebhookEvent(req.body, signature);
  } catch (err) {
    console.error('❌ Webhook signature verification failed:', err.message);
    return res.status(400).json({ error: `Webhook error: ${err.message}` });
  }

  console.log(`📦 Stripe webhook: ${event.type}`);

  // ── STEP 2: Handle each event type ───────────────────────
  try {
    switch (event.type) {

      // ── User completed subscription checkout ──────────────
      case 'checkout.session.completed': {
        const session = event.data.object;

        if (session.metadata?.type === 'subscription') {
          await handleSubscriptionCheckoutComplete(session);
        } else if (session.metadata?.type === 'credit_pack') {
          await handleCreditPackPurchase(session);
        }
        break;
      }

      // ── Monthly subscription renews → refresh credits ──────
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object;
        if (invoice.billing_reason === 'subscription_cycle') {
          await handleSubscriptionRenewal(invoice);
        }
        break;
      }

      // ── Payment failed → notify user ───────────────────────
      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        console.warn(`💳 Payment failed for customer: ${invoice.customer}`);
        // In production: send an email notification via Resend/SendGrid
        break;
      }

      // ── Subscription cancelled or expired ─────────────────
      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        await handleSubscriptionCancelled(sub);
        break;
      }

      // ── Subscription updated (plan change) ────────────────
      case 'customer.subscription.updated': {
        const sub = event.data.object;
        await handleSubscriptionUpdated(sub);
        break;
      }

      // ── Refund issued ──────────────────────────────────────
      case 'charge.refunded': {
        console.log('💸 Refund processed:', event.data.object.id);
        // In production: deduct the refunded credits
        break;
      }

      default:
        console.log(`ℹ️  Unhandled event type: ${event.type}`);
    }

    // Always return 200 so Stripe doesn't retry
    return res.json({ received: true, type: event.type });

  } catch (err) {
    console.error(`❌ Error handling webhook ${event.type}:`, err);
    // Still return 200 — we don't want Stripe to retry
    // Instead log the error and investigate manually
    return res.json({ received: true, error: err.message });
  }
}

// ─────────────────────────────────────────────────────────────
// HANDLER: Subscription checkout completed
// ─────────────────────────────────────────────────────────────
async function handleSubscriptionCheckoutComplete(session) {
  const userId = session.metadata?.darsanai_user_id;
  const planId = session.metadata?.plan;

  if (!userId || !planId) {
    console.error('❌ Webhook missing userId or planId in metadata');
    return;
  }

  // Save Stripe customer ID
  userStore.setStripeCustomerId(userId, session.customer);

  // Activate the plan (grants monthly credits)
  userStore.activatePlan(userId, planId, session.subscription);

  console.log(`✅ Subscription activated: user ${userId} → plan ${planId}`);
}

// ─────────────────────────────────────────────────────────────
// HANDLER: Monthly subscription renewal
// ─────────────────────────────────────────────────────────────
async function handleSubscriptionRenewal(invoice) {
  // Find user by Stripe customer ID
  const user = userStore.getUserByStripeCustomerId(invoice.customer);
  if (!user) {
    console.warn('Webhook: could not find user for customer', invoice.customer);
    return;
  }

  // Find out which plan renewed
  const priceId = invoice.lines?.data?.[0]?.price?.id;
  const plan    = getPlanByStripePriceId(priceId);

  if (plan) {
    // Refresh monthly credits
    userStore.activatePlan(user.id, plan.id, invoice.subscription);
    console.log(`🔄 Subscription renewed: user ${user.id} → ${plan.credits} credits refreshed`);
  }
}

// ─────────────────────────────────────────────────────────────
// HANDLER: Subscription cancelled
// ─────────────────────────────────────────────────────────────
async function handleSubscriptionCancelled(subscription) {
  const user = userStore.getUserByStripeCustomerId(subscription.customer);
  if (!user) return;

  userStore.cancelPlan(user.id);
  console.log(`🚫 Subscription cancelled: user ${user.id} downgraded to free`);
}

// ─────────────────────────────────────────────────────────────
// HANDLER: Subscription updated (plan upgrade/downgrade)
// ─────────────────────────────────────────────────────────────
async function handleSubscriptionUpdated(subscription) {
  const user = userStore.getUserByStripeCustomerId(subscription.customer);
  if (!user) return;

  const priceId = subscription.items?.data?.[0]?.price?.id;
  const plan    = getPlanByStripePriceId(priceId);

  if (plan && plan.id !== user.plan) {
    userStore.activatePlan(user.id, plan.id, subscription.id);
    console.log(`⬆️  Plan changed: user ${user.id} → ${plan.id}`);
  }
}

// ─────────────────────────────────────────────────────────────
// HANDLER: Credit pack purchased (one-time payment)
// ─────────────────────────────────────────────────────────────
async function handleCreditPackPurchase(session) {
  const userId  = session.metadata?.darsanai_user_id;
  const packId  = session.metadata?.pack_id;
  const credits = parseInt(session.metadata?.credits) || 0;

  if (!userId || !credits) {
    console.error('❌ Credit pack webhook missing userId or credits');
    return;
  }

  userStore.setStripeCustomerId(userId, session.customer);
  userStore.addCredits(userId, credits, `Purchased credit pack: ${packId}`);

  console.log(`💰 Credit pack purchased: user ${userId} + ${credits} credits`);
}

module.exports = { handleStripeWebhook };
