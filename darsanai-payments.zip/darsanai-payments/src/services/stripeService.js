// ─────────────────────────────────────────────────────────────
// darsanai.AI — Stripe Service
// All Stripe API interactions live here.
// ─────────────────────────────────────────────────────────────
const Stripe = require('stripe');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
  appInfo: { name: 'darsanai', version: '1.0.0' },
});

const { PLANS, CREDIT_PACKS } = require('../../config/plans');

// ── CREATE OR GET STRIPE CUSTOMER ────────────────────────────
// Every user in darsanai maps to one Stripe Customer
async function getOrCreateCustomer(userId, email, name) {
  // First, search for existing customer with this userId in metadata
  const existing = await stripe.customers.search({
    query: `metadata['darsanai_user_id']:'${userId}'`,
    limit: 1,
  });

  if (existing.data.length > 0) {
    return existing.data[0];
  }

  // Create a new Stripe customer
  const customer = await stripe.customers.create({
    email,
    name,
    metadata: { darsanai_user_id: userId },
  });

  console.log(`👤 Stripe customer created: ${customer.id} for user ${userId}`);
  return customer;
}

// ── CREATE CHECKOUT SESSION (for subscriptions) ──────────────
// This redirects the user to Stripe's hosted checkout page
async function createSubscriptionCheckout({ customerId, planId, userId, successUrl, cancelUrl }) {
  const plan = PLANS[planId];
  if (!plan || !plan.stripePriceId) {
    throw new Error(`Plan "${planId}" has no Stripe price configured`);
  }

  const session = await stripe.checkout.sessions.create({
    customer:   customerId,
    mode:       'subscription',
    line_items: [{
      price:    plan.stripePriceId,
      quantity: 1,
    }],
    // Show trial if plan has one
    subscription_data: plan.trialDays ? {
      trial_period_days: plan.trialDays,
      metadata: { darsanai_user_id: userId, plan: planId },
    } : {
      metadata: { darsanai_user_id: userId, plan: planId },
    },
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}&plan=${planId}`,
    cancel_url:  cancelUrl,
    metadata: { darsanai_user_id: userId, plan: planId, type: 'subscription' },
    allow_promotion_codes: true,
    billing_address_collection: 'auto',
  });

  console.log(`🛒 Checkout session created: ${session.id} for plan ${planId}`);
  return session;
}

// ── CREATE CHECKOUT SESSION (for credit packs) ───────────────
async function createCreditPackCheckout({ customerId, packId, userId, successUrl, cancelUrl }) {
  const pack = CREDIT_PACKS[packId];
  if (!pack || !pack.stripePriceId) {
    throw new Error(`Credit pack "${packId}" has no Stripe price configured`);
  }

  const session = await stripe.checkout.sessions.create({
    customer:   customerId,
    mode:       'payment',            // one-time payment
    line_items: [{
      price:    pack.stripePriceId,
      quantity: 1,
    }],
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}&pack=${packId}`,
    cancel_url:  cancelUrl,
    metadata: {
      darsanai_user_id: userId,
      pack_id:        packId,
      credits:        String(pack.credits),
      type:           'credit_pack',
    },
    allow_promotion_codes: true,
  });

  console.log(`🛒 Credit pack checkout: ${session.id} for pack ${packId}`);
  return session;
}

// ── CREATE BILLING PORTAL SESSION ────────────────────────────
// Lets users manage their subscription, cancel, update payment method
async function createBillingPortalSession(customerId, returnUrl) {
  const session = await stripe.billingPortal.sessions.create({
    customer:   customerId,
    return_url: returnUrl,
  });
  return session;
}

// ── CANCEL SUBSCRIPTION ───────────────────────────────────────
async function cancelSubscription(subscriptionId) {
  // Cancel at end of billing period (not immediately)
  const sub = await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: true,
  });
  console.log(`🚫 Subscription ${subscriptionId} set to cancel at period end`);
  return sub;
}

// ── GET SUBSCRIPTION ──────────────────────────────────────────
async function getSubscription(subscriptionId) {
  return stripe.subscriptions.retrieve(subscriptionId);
}

// ── VERIFY WEBHOOK SIGNATURE ──────────────────────────────────
// CRITICAL: always verify webhooks to prevent fraud
function constructWebhookEvent(rawBody, signature) {
  return stripe.webhooks.constructEvent(
    rawBody,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET
  );
}

// ── GET CHECKOUT SESSION ──────────────────────────────────────
async function getCheckoutSession(sessionId) {
  return stripe.checkout.sessions.retrieve(sessionId, {
    expand: ['subscription', 'payment_intent'],
  });
}

module.exports = {
  stripe,
  getOrCreateCustomer,
  createSubscriptionCheckout,
  createCreditPackCheckout,
  createBillingPortalSession,
  cancelSubscription,
  getSubscription,
  constructWebhookEvent,
  getCheckoutSession,
};
