# 💳 darsanai — Payments & Credits System

Complete Stripe integration for subscriptions, credit packs, and usage billing.

---

## 📁 Folder Structure

```
darsanai-payments/
├── config/
│   └── plans.js                  ← All plan/pricing config (edit prices here)
├── src/
│   ├── server.js                 ← Express server (port 3002)
│   ├── services/
│   │   └── stripeService.js      ← All Stripe API calls
│   ├── webhooks/
│   │   └── stripeWebhook.js      ← Handles Stripe payment events ⭐
│   ├── routes/
│   │   ├── payments.js           ← Checkout, billing portal endpoints
│   │   └── credits.js            ← Credit balance and deduction
│   └── models/
│       └── userStore.js          ← User plans + credit balances
├── pricing-page.html             ← Ready-to-use pricing UI
└── .env.example
```

---

## ⚡ Setup (4 steps)

### Step 1 — Install
```bash
npm install
cp .env.example .env
```

### Step 2 — Create Stripe products
1. Go to https://dashboard.stripe.com
2. **Products** → **Add product**
3. Create these 5 products:

| Product Name    | Price    | Type      |
|----------------|----------|-----------|
| Creator Plan   | $29/mo   | Recurring |
| Studio Plan    | $99/mo   | Recurring |
| 100 Credits    | $4.99    | One-time  |
| 500 Credits    | $19.99   | One-time  |
| 2000 Credits   | $59.99   | One-time  |

4. Copy each **Price ID** (starts with `price_...`) to your `.env`

### Step 3 — Set up webhook
```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Forward webhooks to your local server
stripe listen --forward-to localhost:3002/webhooks/stripe
# Copy the webhook secret (whsec_...) to STRIPE_WEBHOOK_SECRET in .env
```

### Step 4 — Start server
```bash
npm run dev
# Server starts on http://localhost:3002
```

---

## 🔌 API Reference

### Get all plans (for pricing page)
```
GET /api/payments/plans
Response: { plans: [...], creditPacks: [...] }
```

### Create subscription checkout
```
POST /api/payments/checkout/plan
Headers: x-user-id: user-123
Body: { "planId": "creator", "email": "user@example.com" }
Response: { "checkoutUrl": "https://checkout.stripe.com/..." }
→ Redirect user to checkoutUrl
```

### Create credit pack checkout
```
POST /api/payments/checkout/credits
Headers: x-user-id: user-123
Body: { "packId": "medium" }
Response: { "checkoutUrl": "https://checkout.stripe.com/..." }
```

### Open billing portal (manage subscription)
```
POST /api/payments/portal
Headers: x-user-id: user-123
Response: { "portalUrl": "https://billing.stripe.com/..." }
→ Redirect user to portalUrl
```

### Check if user can generate (before generating)
```
POST /api/credits/check
Headers: x-user-id: user-123
Body: { "duration": 5, "resolution": "4K" }
Response: {
  "allowed": true,
  "creditsRequired": 10,
  "creditsAvailable": 172,
  "creditsAfter": 162
}
```

### Get user credit balance
```
GET /api/credits
Headers: x-user-id: user-123
Response: { "available": 172, "used": 128, "plan": "creator" }
```

---

## 💡 How credits work

| Action | Credits Used |
|--------|-------------|
| Generate 3s video | 6 credits |
| Generate 5s video | 10 credits |
| Generate 8s video | 16 credits |
| Generate 10s video | 20 credits |
| Generate 15s video | 30 credits |

Credits per second is configured via `CREDITS_PER_SECOND=2` in `.env`

---

## 🔗 Integration with the Video Backend

After a video is generated successfully, the worker calls the credits API:

```javascript
// In videoWorker.js, after video generation completes:
await fetch('http://localhost:3002/api/credits/deduct', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-secret': process.env.API_SECRET,   // internal auth
  },
  body: JSON.stringify({
    userId,
    duration,
    jobId,
  }),
});
```

---

## 🚀 Deploying to Production

1. Switch from test keys (`sk_test_...`) to live keys (`sk_live_...`)
2. Create a real webhook endpoint in Stripe Dashboard → Developers → Webhooks
3. Point it to: `https://your-backend.railway.app/webhooks/stripe`
4. Select events: `checkout.session.completed`, `invoice.payment_succeeded`, `customer.subscription.deleted`, `customer.subscription.updated`

---

## ✅ What's complete

- [x] Stripe subscription checkout (Creator + Studio plans)
- [x] Stripe one-time credit pack checkout
- [x] Stripe billing portal (manage/cancel subscription)
- [x] Webhook handler for all payment events
- [x] Automatic credit grants on payment
- [x] Monthly credit refresh on renewal
- [x] Automatic downgrade on cancellation
- [x] Credit check before video generation
- [x] Credit deduction after generation
- [x] Transaction history
- [x] Beautiful pricing page UI
- [x] Annual billing toggle (20% discount)

---

*Built for darsanai — Cinematic AI Video Generation*
