# 🔐 darsanai — Authentication System

Complete Clerk auth integration: sign in, sign up, OTP verification, JWT-protected routes.

---

## 📁 What's in this folder

```
darsanai-auth/
├── frontend/
│   ├── auth.html               ← Standalone auth UI (sign in / sign up / OTP)
│   ├── .env.example            ← Frontend environment variables
│   └── src/lib/
│       ├── clerkAuth.js        ← React hooks + Clerk integration code
│       └── apiClient.js        ← All backend API calls in one place
└── backend/
    └── src/middleware/
        └── clerkAuth.js        ← Real JWT verification middleware
```

---

## ⚡ Setup (3 steps)

### Step 1 — Create a Clerk app (free)
1. Go to https://dashboard.clerk.com
2. Click **"Add application"**
3. Name it `darsanai`
4. Enable: **Email/Password** + **Google OAuth** + **GitHub OAuth**
5. Copy your keys:
   - **Publishable key** → `VITE_CLERK_PUBLISHABLE_KEY` (frontend)
   - **Secret key** → `CLERK_SECRET_KEY` (backend)

### Step 2 — Frontend setup (React + Vite)
```bash
cd your-react-app
npm install @clerk/clerk-react

# Create .env.local
cp .env.example .env.local
# Paste your VITE_CLERK_PUBLISHABLE_KEY
```

Then in your `main.jsx`:
```jsx
import { ClerkProvider } from '@clerk/clerk-react';

ReactDOM.createRoot(document.getElementById('root')).render(
  <ClerkProvider publishableKey={import.meta.env.VITE_CLERK_PUBLISHABLE_KEY}
                 afterSignInUrl="/dashboard"
                 afterSignUpUrl="/dashboard">
    <App />
  </ClerkProvider>
);
```

### Step 3 — Backend setup
```bash
cd darsanai-backend
npm install @clerk/backend

# Add to your .env:
CLERK_SECRET_KEY=sk_test_your_secret_key
```

Replace the auth middleware in `src/middleware/auth.js` with `clerkAuth.js`:
```javascript
// In all your routes, replace:
const { requireAuth } = require('../middleware/auth');
// With:
const { requireAuth } = require('../middleware/clerkAuth');
```

---

## 🗺️ User Flow

```
User visits darsanai
       ↓
Not signed in → redirect to /sign-in
       ↓
User fills form → Clerk verifies
       ↓
Success → Clerk creates session + sets cookie
       ↓
Frontend gets JWT token from Clerk
       ↓
Every API call sends: Authorization: Bearer <token>
       ↓
Backend verifies token with Clerk SDK
       ↓
req.userId = "user_2abc123" → route executes ✅
```

---

## 🔌 Using Auth in Your React Components

```jsx
import { useAuth } from '@clerk/clerk-react';
import { createApiClient, pollJob } from './lib/apiClient';

function Generate() {
  const { getToken } = useAuth();
  const api = createApiClient(getToken);

  async function handleGenerate(prompt) {
    // 1. Check credits first
    const check = await api.checkCredits({ duration: 5 });
    if (!check.allowed) { alert(check.reason); return; }

    // 2. Submit generation job
    const { jobId } = await api.generateText({
      prompt, style: 'Cinematic', duration: 5, resolution: '4K'
    });

    // 3. Poll until done (updates progress bar)
    const result = await pollJob(api, jobId, (pct) => setProgress(pct));

    // 4. Show the video
    setVideoUrl(result.videoUrl);
  }
}
```

---

## 🛡️ Protected Routes Setup (React Router v6)

```jsx
import { useAuth }    from '@clerk/clerk-react';
import { Navigate }   from 'react-router-dom';

function ProtectedRoute({ children }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div>Loading…</div>;
  if (!isSignedIn) return <Navigate to="/sign-in" replace />;
  return children;
}

// In your router:
<Routes>
  <Route path="/"          element={<LandingPage />} />
  <Route path="/sign-in"   element={<SignInPage />} />
  <Route path="/sign-up"   element={<SignUpPage />} />
  <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
  <Route path="/generate"  element={<ProtectedRoute><Generate /></ProtectedRoute>} />
  <Route path="/gallery"   element={<ProtectedRoute><Gallery /></ProtectedRoute>} />
</Routes>
```

---

## ✅ What's complete

- [x] Beautiful sign in page (email + Google + GitHub)
- [x] Sign up with email verification (OTP)
- [x] Forgot password flow
- [x] Password strength indicator
- [x] Clerk React hooks + `usedarsanaiAuth` custom hook
- [x] JWT middleware for Node.js backend
- [x] Full API client with auto-attached tokens
- [x] Protected route component
- [x] Polling helper for video generation jobs

---

## 🗺️ Your complete project — all done!

| # | Module | Status |
|---|---|---|
| 1 | Landing page | ✅ |
| 2 | React App UI | ✅ |
| 3 | Node.js Backend + Runway API | ✅ |
| 4 | Stripe Payments + Credits | ✅ |
| 5 | User Auth (Clerk) | ✅ |
| **6** | **Deploy everything online** | ⬅ Last step! |
