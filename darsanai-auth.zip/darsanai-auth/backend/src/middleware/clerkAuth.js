// ─────────────────────────────────────────────────────────────
// darsanai.AI — Production Auth Middleware (Clerk JWT)
//
// Replace the stub auth in the backend with this file.
// Install: npm install @clerk/backend
// ─────────────────────────────────────────────────────────────
const { createClerkClient } = require('@clerk/backend');

const clerk = createClerkClient({
  secretKey: process.env.CLERK_SECRET_KEY,
});

// ── REQUIRE AUTH: verifies Clerk JWT on every protected route ──
async function requireAuth(req, res, next) {
  // ── DEV MODE: skip auth if no Clerk key is set ────────────
  if (process.env.NODE_ENV === 'development' && !process.env.CLERK_SECRET_KEY) {
    req.userId   = req.headers['x-user-id'] || 'dev-user-123';
    req.userPlan = 'creator';
    return next();
  }

  // ── PRODUCTION: verify JWT ────────────────────────────────
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No authorization token provided' });
    }

    const token   = authHeader.split(' ')[1];
    const payload = await clerk.verifyToken(token);

    req.userId    = payload.sub;             // Clerk user ID (e.g. "user_2abc123")
    req.sessionId = payload.sid;
    next();

  } catch (err) {
    console.error('Auth error:', err.message);
    return res.status(401).json({ error: 'Invalid or expired token. Please sign in again.' });
  }
}

// ── OPTIONAL AUTH: don't fail if no token, but attach user if present ──
async function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return next();

  try {
    const token   = authHeader.split(' ')[1];
    const payload = await clerk.verifyToken(token);
    req.userId    = payload.sub;
  } catch (_) {
    // No valid token — just continue as unauthenticated
  }
  next();
}

// ── GET FULL USER from Clerk (name, email, image) ─────────────
async function getClerkUser(userId) {
  try {
    const user = await clerk.users.getUser(userId);
    return {
      id:        user.id,
      firstName: user.firstName,
      lastName:  user.lastName,
      email:     user.emailAddresses[0]?.emailAddress || '',
      imageUrl:  user.imageUrl,
      createdAt: user.createdAt,
    };
  } catch (err) {
    console.error('Could not fetch Clerk user:', err.message);
    return null;
  }
}

module.exports = { requireAuth, optionalAuth, getClerkUser };
